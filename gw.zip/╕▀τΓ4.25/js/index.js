// (function($){
// 	// 左侧导航点击消失
// 	$(function(){
// 		$('.mean-expand').prev().hide()
// 		$('.mean-expand').click(function(){
// 			$(this).prev().slideToggle(200)
// 			if($(this).html()=="&gt;"){
// 				$(this).html("^")
// 			}else{
// 				$(this).html("&gt;")
// 			}
// 		})
// 	});
// 	// 二级nav
// 	$(function(){
// 		$(".app1").children("li").hover(function(){
// 			$(this).addClass("on").children().css({"color":"#99c45e"});
// 		},function(){
// 			$(this).removeClass("on").children().css({"color":""});
// 		});
// 		// 二级里的选项卡
// 		// 海丁顿
// 		$("#hdd1").hover(function(){
// 			$(".hdd").addClass("om");
// 		},function(){
// 			$(".hdd").removeClass("om");
// 		})
// 		$(".hdd").hover(function(){
// 			$(this).addClass("om");
// 		},function(){
// 			$(this).removeClass("om");
// 		})
// 		// 英国
// 		$(".yg").hover(function(){
// 			$("#yg1").addClass("ol");
// 		},function(){
// 			$("#yg1").removeClass("ol");
// 		})
// 		$("#yg1").hover(function(){
// 			$(this).addClass("ol");
// 		},function(){
// 			$(this).removeClass("ol");
// 		})
// 		// 联系我们
// 		$("#lxxm").hover(function(){
// 			$(".lxwm").addClass("ox");
// 		},function(){
// 			$(".lxwm").removeClass("ox");
// 		})
// 		$(".lxwm").hover(function(){
// 			$(this).addClass("ox");
// 		},function(){
// 			$(this).removeClass("ox");
// 		})
// 		// 二级里的选项卡
// 		$(".hdd").children(".row").children("ul").children("li").hover(function(){
// 			var i=$(this).index();
// 			$("#lbb1").children("div").eq(i-1).css("display","block").siblings("div").css("display","none");
// 		})
// 		$("#yg1").children(".row").children("ul").children("li").hover(function(){
// 			var i=$(this).index();
// 			$("#lbb2").children("div").eq(i-1).css("display","block").siblings("div").css("display","none");
// 		})
// 		$(".lxwm").children(".row").children("ul").children("li").hover(function(){
// 			var i=$(this).index();
// 			$("#lxwm1").children("div").eq(i-1).css("display","block").siblings("div").css("display","none");
// 		})
// 	})
// })(jQuery)
